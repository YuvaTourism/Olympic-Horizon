
  document.addEventListener("DOMContentLoaded", function() {
    let link = document.createElement("link");
    link.rel = "icon";
    link.href = "css/img/logo.png";
    document.head.appendChild(link);
  });
